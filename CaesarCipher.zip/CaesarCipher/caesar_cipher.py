def get_input(): 
    text = input("Enter your text here please: ")
    shift = int(input("Enter the shift number please: "))
    choise = input("if you want to encrypt type e and if you want to decrypt type d: ")
    while not choise == "e" or choise == "E" or choise == "d" or choise == "D":
        choise = input("please type valid choise: ")
    return text, shift , choise

def caesar_cipher(text, shift):
    result = ""
    for char in text:  
        if 'A' <= char <= 'Z':  
            shifted = ord(char) + shift
            if shifted > ord('Z'):
                shifted -= 26  
            elif shifted < ord('A'):
                shifted += 26  
            result += chr(shifted)

        elif 'a' <= char <= 'z':
            shifted = ord(char) + shift
            if shifted > ord('z'):
                shifted -= 26
            elif shifted < ord('a'):
                shifted += 26
            result += chr(shifted)

        else:
            result += char
    return result

text, shift , choise = get_input()
if choise == "e" or choise == "E":
    encrypted = caesar_cipher(text, shift)
    print("Encrypted Text:", encrypted)
else:
    decrypted = caesar_cipher(encrypted, -shift)
    print("Decrypted Text:", decrypted)
